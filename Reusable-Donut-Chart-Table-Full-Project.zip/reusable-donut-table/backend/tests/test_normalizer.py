import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from main import normalize_payload, parse_upload


def gateway_cell(value):
    return {"value": value, "type": "c", "dataType": "C"}


def test_sojourner_gateway_json_maps_projects_and_budget():
    payload = {
        "id": "upload-1",
        "pushType": "Global Budget Display.MCCDB",
        "fields": [
            {
                "name": "Projects",
                "fieldNature": "table",
                "tableField": {
                    "headers": ["Project ID", "Project Name", "Global MYFP", "Payments"],
                    "rows": [
                        {"columns": [gateway_cell("5100000"), gateway_cell("Transmission Project"), gateway_cell("1200.50"), gateway_cell("200")]},
                        {"columns": [gateway_cell("5200000"), gateway_cell("Road Project"), gateway_cell("800"), gateway_cell("50")]},
                    ],
                },
            },
            {
                "name": "Yearwise",
                "fieldNature": "table",
                "tableField": {
                    "headers": ["Project ID", "Fiscal Year", "Global MYFP"],
                    "rows": [{"columns": [gateway_cell("5100000"), gateway_cell("2026"), gateway_cell("400")]}],
                },
            },
        ],
    }
    result = normalize_payload(payload)
    assert result["mapping"]["labelColumn"] == "Project Name"
    assert result["mapping"]["valueColumn"] == "Global MYFP"
    assert [row["name"] for row in result["rows"]] == ["Transmission Project", "Road Project"]
    assert [row["amount"] for row in result["rows"]] == [1200.5, 800.0]


def test_nested_generic_json_keeps_hierarchy():
    payload = {
        "title": "Donations",
        "rows": [
            {
                "id": "p1",
                "name": "Donor A",
                "amount": 1000,
                "children": [{"id": "c1", "name": "Grant 1", "amount": 400}],
            }
        ],
    }
    result = normalize_payload(payload)
    assert result["rows"][0]["name"] == "Donor A"
    assert result["rows"][0]["amount"] == 1000
    assert result["rows"][0]["children"][0]["name"] == "Grant 1"


def test_csv_auto_maps_project_and_budget_columns():
    result = parse_upload("budgets.csv", b"Project Name,Global MYFP,Payments\nTransmission Project,1200,50\nRoad Project,700,20\n")
    assert result["mapping"]["labelColumn"] == "Project Name"
    assert result["mapping"]["valueColumn"] == "Global MYFP"
    assert len(result["rows"]) == 2
