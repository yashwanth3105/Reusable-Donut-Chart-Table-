from __future__ import annotations

import csv
import io
import json
import os
import re
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from openpyxl import load_workbook

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("DONUT_TABLE_DB", str(BASE_DIR / "data" / "donut_table.sqlite3")))
MAX_UPLOAD_BYTES = 15 * 1024 * 1024
ALLOWED_EXTENSIONS = {".json", ".csv", ".tsv", ".xlsx", ".xlsm"}
DEFAULT_TITLE = "Total Budget by Project"

app = FastAPI(title="Reusable Donut Chart + Table API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


def db_connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(DB_PATH), timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database() -> None:
    with db_connect() as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS uploads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                source_format TEXT NOT NULL,
                title TEXT NOT NULL,
                source_table TEXT,
                label_column TEXT,
                value_column TEXT,
                row_count INTEGER NOT NULL,
                total_amount REAL,
                rows_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS normalized_rows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                upload_id INTEGER NOT NULL REFERENCES uploads(id) ON DELETE CASCADE,
                parent_row_id INTEGER REFERENCES normalized_rows(id) ON DELETE CASCADE,
                depth INTEGER NOT NULL,
                row_name TEXT NOT NULL,
                amount REAL,
                row_json TEXT NOT NULL
            );
            """
        )


initialize_database()


def clean_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def label_score(key: str) -> int:
    k = clean_key(key)
    if not k or k.endswith("id") or k in {"id", "code", "projectcode", "donorcode"}:
        return -100
    # Measures often contain words such as "projected"; they must never be chosen as labels.
    if any(term in k for term in ("commitment", "disbursement", "budget", "myfp", "amount", "value", "payment", "invoice", "balance", "uncommitted", "projected", "actual", "percentage", "percent", "fiscalyear")):
        return -100
    scores = {
        "projectname": 140, "donorname": 140, "categoryname": 125,
        "activityname": 120, "subactivityname": 120, "recipientname": 115,
        "project": 110, "donor": 110, "category": 105, "name": 100,
        "label": 90, "description": 82, "recipient": 80, "fundname": 80,
        "activity": 75, "item": 65, "title": 60,
    }
    if k in scores:
        return scores[k]
    for term, value in scores.items():
        if len(term) > 4 and term in k:
            return value - 8
    if "id" in k:
        return -80
    return 0


def value_score(key: str) -> int:
    k = clean_key(key)
    if not k:
        return -100
    if any(term in k for term in ("percent", "percentage", "perc", "ratio", "rate", "fiscalyear", "date", "year", "id", "code")):
        return -100
    # Budget/MYFP and donation amount measures are preferred for the donut.
    terms = [
        ("totalbudget", 150), ("budgetamount", 145), ("donationamount", 145),
        ("amountdonated", 145), ("donatedamount", 145), ("contributionamount", 140),
        ("globalmyfp", 138), ("projectmyfp", 136), ("myfp", 125),
        ("budget", 130), ("donation", 120), ("contribution", 112),
        ("actualcommitmentvalue", 105), ("actualcommitmentsvalue", 104),
        ("actualcommitments", 100), ("totalamount", 110), ("amount", 90),
        ("projectedcommitmentvalue", 82), ("projectedcommitmentsvalue", 82),
        ("disbursementvalue", 80), ("disbursements", 76), ("commitments", 74),
        ("payments", 70), ("invoices", 66), ("expenditure", 78),
        ("funding", 65), ("balance", 55), ("cost", 54), ("value", 52),
        ("total", 40),
    ]
    for term, score in terms:
        if k == term:
            return score
    for term, score in terms:
        if len(term) > 4 and term in k:
            return score - 10
    return 0


def parse_number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text_value = str(value).strip()
    if not text_value or text_value in {"—", "-", "N/A", "n/a", "null", "None"}:
        return None
    negative = text_value.startswith("(") and text_value.endswith(")")
    text_value = text_value.strip("()").replace(",", "").replace("$", "").replace("€", "").replace("£", "").replace("₹", "").strip()
    if text_value.endswith("%"):
        text_value = text_value[:-1].strip()
    try:
        number = float(text_value)
        return -number if negative else number
    except ValueError:
        return None


def normalize_table_field(field: dict[str, Any]) -> dict[str, Any] | None:
    table_field = field.get("tableField") or field.get("table") or {}
    headers = table_field.get("headers")
    rows = table_field.get("rows")
    if not isinstance(headers, list) or not isinstance(rows, list):
        return None
    records: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        columns = row.get("columns")
        if not isinstance(columns, list):
            # Also accept JSON tables whose row is already a dictionary.
            records.append(dict(row))
            continue
        values: dict[str, Any] = {}
        for index, header in enumerate(headers):
            cell = columns[index] if index < len(columns) else None
            if isinstance(cell, dict) and "value" in cell:
                values[str(header)] = cell.get("value")
            else:
                values[str(header)] = cell
        records.append(values)
    return {"name": str(field.get("name") or field.get("fieldLabel") or "Table"), "headers": [str(h) for h in headers], "records": records}


def best_label_column(headers: list[str]) -> str | None:
    if not headers:
        return None
    selected = max(headers, key=label_score)
    return selected if label_score(selected) > 0 else None


def best_value_column(headers: list[str], preferred: str | None = None) -> str | None:
    if not headers:
        return None
    preferred_norm = clean_key(preferred) if preferred else ""
    def score(header: str) -> int:
        base = value_score(header)
        key = clean_key(header)
        if preferred_norm:
            if key == preferred_norm:
                base += 90
            elif key and (key in preferred_norm or preferred_norm in key):
                base += 45
            else:
                # Prefer columns sharing meaning words with the selected metric.
                preferred_terms = {part for part in re.findall(r"[a-z]+", str(preferred or "").casefold()) if len(part) > 3}
                header_terms = {part for part in re.findall(r"[a-z]+", header.casefold()) if len(part) > 3}
                base += 8 * len(preferred_terms & header_terms)
        return base
    selected = max(headers, key=score)
    return selected if score(selected) > 0 else None


def count_tree(rows: list[dict[str, Any]]) -> int:
    return sum(1 + count_tree(row.get("children") or []) for row in rows)


def total_tree(rows: list[dict[str, Any]]) -> float | None:
    amounts = [row.get("amount") for row in rows if isinstance(row.get("amount"), (int, float))]
    if not amounts:
        return None
    return round(sum(float(v) for v in amounts), 2)


def row_id(value: Any = None) -> str:
    return str(value).strip() if value not in (None, "") else uuid.uuid4().hex[:12]


def normalize_generic_records(records: list[Any], *, source_table: str | None = None, explicit_title: str | None = None) -> dict[str, Any]:
    if not records:
        raise ValueError("The uploaded file contains no data rows.")
    dictionaries = [r for r in records if isinstance(r, dict)]
    if not dictionaries:
        raise ValueError("The data rows must be objects with a name/category column and a numeric amount column.")
    headers = list(dict.fromkeys(str(key) for record in dictionaries for key in record.keys()))
    label_key = best_label_column(headers)
    value_key = best_value_column(headers)
    if not label_key:
        raise ValueError("Could not identify the project/category name column. Include a column such as Project Name, Name, Category, or Donor Name.")
    if not value_key:
        raise ValueError("Could not identify a numeric measure column. Include a column such as Budget, Amount, Donation Amount, Global MYFP, or Value.")

    def convert(items: list[Any], depth: int = 0) -> list[dict[str, Any]]:
        if depth > 2:
            raise ValueError("Only three levels are supported: Project/Category → Activity → Sub-Activity.")
        output = []
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            local_headers = [str(k) for k in item.keys()]
            local_label = label_key if label_key in item else best_label_column(local_headers)
            local_value = "amount" if "amount" in item and parse_number(item.get("amount")) is not None else (
                value_key if value_key in item else best_value_column(local_headers, value_key)
            )
            name = item.get(local_label) if local_label else None
            if name is None or str(name).strip() == "":
                # Explicit hierarchy data may use "name" even when top-level source headers differ.
                name = item.get("name") or item.get("projectName") or item.get("category") or item.get("label")
            if name is None or str(name).strip() == "":
                continue
            raw_amount = item.get(local_value) if local_value else item.get("amount")
            amount = parse_number(raw_amount)
            children_raw = item.get("children")
            children = convert(children_raw, depth + 1) if isinstance(children_raw, list) else []
            output.append({
                "id": row_id(item.get("id") or item.get("projectId") or item.get("activityId")),
                "name": str(name).strip(),
                "amount": amount,
                "children": children,
            })
        return output

    rows = convert(records)
    if not rows:
        raise ValueError("No usable rows were found. Check that names are filled in.")
    if not any(row.get("amount") is not None for row in rows):
        raise ValueError("The selected amount column does not contain numeric values.")
    return {
        "title": explicit_title or DEFAULT_TITLE,
        "rows": rows,
        "mapping": {"labelColumn": label_key, "valueColumn": value_key, "sourceTable": source_table},
    }


def normalize_sojourner_payload(payload: dict[str, Any]) -> dict[str, Any] | None:
    fields = payload.get("fields")
    if not isinstance(fields, list):
        return None
    tables = [table for field in fields if isinstance(field, dict) if (table := normalize_table_field(field))]
    if not tables:
        return None

    def table_score(table: dict[str, Any]) -> int:
        key = clean_key(table["name"])
        headers = table["headers"]
        label = best_label_column(headers)
        measure = best_value_column(headers)
        name_points = 130 if key == "projects" else 125 if key in {"totalproject", "project"} else 95 if "project" in key else 10
        if label:
            name_points += min(35, label_score(label) // 4)
        if measure:
            name_points += min(30, value_score(measure) // 5)
        if "year" in key or "quarter" in key or "totalsgraph" in key:
            name_points -= 100
        return name_points

    candidates = [table for table in tables if best_label_column(table["headers"]) and best_value_column(table["headers"])]
    if not candidates:
        return None
    root = max(candidates, key=table_score)
    root_label = best_label_column(root["headers"])
    root_metric = best_value_column(root["headers"])
    if not root_label or not root_metric:
        return None

    def find_header(headers: list[str], kind: str) -> str | None:
        normalized = [(h, clean_key(h)) for h in headers]
        if kind == "project_id":
            options = [(h, key) for h, key in normalized if key in {"projectid", "projectcode"}]
        elif kind == "activity_id":
            options = [(h, key) for h, key in normalized if key in {"activityid", "activitycode"}]
        else:
            options = [(h, key) for h, key in normalized if key in {"subactivityid", "subactivitycode"}]
        return options[0][0] if options else None

    root_id_key = find_header(root["headers"], "project_id")
    roots: list[dict[str, Any]] = []
    root_by_id: dict[str, dict[str, Any]] = {}
    for i, record in enumerate(root["records"]):
        name = record.get(root_label)
        if name is None or not str(name).strip():
            continue
        key = str(record.get(root_id_key, "")).strip() if root_id_key else ""
        node = {
            "id": row_id(key or f"{root['name']}-{i}"),
            "name": str(name).strip(),
            "amount": parse_number(record.get(root_metric)),
            "children": [],
        }
        roots.append(node)
        if key:
            root_by_id[key] = node

    if not roots:
        raise ValueError("The selected Sojourner table has no named rows.")

    activity_table = next((t for t in tables if "activity" in clean_key(t["name"]) and "subactivity" not in clean_key(t["name"])), None)
    subactivity_table = next((t for t in tables if "subactivity" in clean_key(t["name"])), None)
    metric_mapping = root_metric

    activity_by_code: dict[str, dict[str, Any]] = {}
    if activity_table:
        activity_name_key = best_label_column(activity_table["headers"])
        activity_metric = best_value_column(activity_table["headers"], root_metric)
        project_link = find_header(activity_table["headers"], "project_id")
        activity_link = find_header(activity_table["headers"], "activity_id")
        if activity_name_key:
            for i, record in enumerate(activity_table["records"]):
                name = record.get(activity_name_key)
                project_key = str(record.get(project_link, "")).strip() if project_link else ""
                parent = root_by_id.get(project_key)
                if name is None or not str(name).strip() or parent is None:
                    continue
                node = {
                    "id": row_id(record.get(activity_link) if activity_link else f"activity-{i}"),
                    "name": str(name).strip(),
                    "amount": parse_number(record.get(activity_metric)) if activity_metric else None,
                    "children": [],
                }
                parent["children"].append(node)
                if activity_link and record.get(activity_link) not in (None, ""):
                    activity_by_code[str(record[activity_link]).strip()] = node
            if activity_metric:
                metric_mapping = f"{root_metric} (activity: {activity_metric})"

    if subactivity_table and activity_by_code:
        sub_name_key = best_label_column(subactivity_table["headers"])
        sub_metric = best_value_column(subactivity_table["headers"], root_metric)
        parent_activity_key = find_header(subactivity_table["headers"], "activity_id")
        sub_id_key = find_header(subactivity_table["headers"], "subactivity_id")
        if sub_name_key and parent_activity_key:
            for i, record in enumerate(subactivity_table["records"]):
                parent_code = str(record.get(parent_activity_key, "")).strip()
                parent = activity_by_code.get(parent_code)
                name = record.get(sub_name_key)
                if not parent or name is None or not str(name).strip():
                    continue
                parent["children"].append({
                    "id": row_id(record.get(sub_id_key) if sub_id_key else f"subactivity-{i}"),
                    "name": str(name).strip(),
                    "amount": parse_number(record.get(sub_metric)) if sub_metric else None,
                    "children": [],
                })
                if sub_metric:
                    metric_mapping = f"{root_metric} (nested: {sub_metric})"

    rows = roots
    flat = [root_row for root_row in rows]
    if not any(row["amount"] is not None for row in rows):
        raise ValueError(f"The detected measure column '{root_metric}' has no numeric values.")

    return {
        "title": DEFAULT_TITLE,
        "rows": rows,
        "mapping": {
            "labelColumn": root_label,
            "valueColumn": root_metric,
            "nestedValueColumns": metric_mapping if metric_mapping != root_metric else None,
            "sourceTable": root["name"],
            "sourceFormat": "Sojourner gateway JSON",
        },
    }


def normalize_payload(payload: Any) -> dict[str, Any]:
    if isinstance(payload, dict):
        gateway = normalize_sojourner_payload(payload)
        if gateway:
            return gateway
        explicit_title = payload.get("title") if isinstance(payload.get("title"), str) else None
        for key in ("rows", "records", "data", "items", "projects", "donors"):
            value = payload.get(key)
            if isinstance(value, list):
                return normalize_generic_records(value, source_table=key, explicit_title=explicit_title)
        # Single record JSON is less likely than a dataset and must not be treated as a table by accident.
        raise ValueError('JSON structure not recognized. Provide a "rows" array, a list of records, or a Sojourner gateway JSON with a "fields" array.')
    if isinstance(payload, list):
        return normalize_generic_records(payload)
    raise ValueError("JSON must contain an array of data rows or a Sojourner report object.")


def parse_csv_bytes(contents: bytes, delimiter: str | None = None) -> list[dict[str, Any]]:
    try:
        text = contents.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV must use UTF-8 text encoding.") from exc
    if not text.strip():
        raise ValueError("The CSV file is empty.")
    if delimiter is None:
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=",;\t|")
            delimiter = dialect.delimiter
        except csv.Error:
            delimiter = ","
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        raise ValueError("CSV needs a header row.")
    return [{str(k).strip(): v for k, v in row.items() if k is not None} for row in reader if any(v not in (None, "") for v in row.values())]


def parse_excel_bytes(contents: bytes) -> list[dict[str, Any]]:
    try:
        workbook = load_workbook(io.BytesIO(contents), read_only=True, data_only=True)
    except Exception as exc:
        raise ValueError("Could not read this Excel workbook. Upload a valid .xlsx or .xlsm file.") from exc
    try:
        # Prefer a sheet with project rows when a workbook has named report tabs.
        sheet = next((s for s in workbook.worksheets if "project" in s.title.casefold()), workbook.active)
        values = sheet.iter_rows(values_only=True)
        headers_row = next(values, None)
        if not headers_row:
            raise ValueError("The Excel sheet is empty.")
        headers = [str(value).strip() if value is not None else "" for value in headers_row]
        while headers and not headers[-1]:
            headers.pop()
        if not any(headers):
            raise ValueError("The first row of the Excel sheet must contain column headers.")
        records = []
        for cells in values:
            record = {headers[i]: cells[i] if i < len(cells) else None for i in range(len(headers)) if headers[i]}
            if any(value not in (None, "") for value in record.values()):
                records.append(record)
        if not records:
            raise ValueError("The Excel sheet contains no data rows.")
        return records
    finally:
        workbook.close()


def parse_upload(filename: str, contents: bytes) -> dict[str, Any]:
    suffix = Path(filename).suffix.casefold()
    if suffix not in ALLOWED_EXTENSIONS:
        raise ValueError("Unsupported file type. Upload JSON, CSV, TSV, XLSX, or XLSM.")
    if not contents:
        raise ValueError("The uploaded file is empty.")
    if suffix == ".json":
        try:
            payload = json.loads(contents.decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("The JSON file is invalid or is not UTF-8 encoded.") from exc
        result = normalize_payload(payload)
        result["source_format"] = "json"
        return result
    if suffix in {".csv", ".tsv"}:
        records = parse_csv_bytes(contents, "\t" if suffix == ".tsv" else None)
        result = normalize_generic_records(records, source_table="CSV table")
        result["source_format"] = suffix.lstrip(".")
        return result
    records = parse_excel_bytes(contents)
    result = normalize_generic_records(records, source_table="Excel worksheet")
    result["source_format"] = suffix.lstrip(".")
    return result


def store_rows(connection: sqlite3.Connection, upload_id: int, rows: list[dict[str, Any]], parent_id: int | None = None, depth: int = 0) -> None:
    for row in rows:
        cursor = connection.execute(
            """INSERT INTO normalized_rows (upload_id, parent_row_id, depth, row_name, amount, row_json)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (upload_id, parent_id, depth, row["name"], row.get("amount"), json.dumps(row, ensure_ascii=False)),
        )
        store_rows(connection, upload_id, row.get("children") or [], cursor.lastrowid, depth + 1)


def serialize_upload(record: sqlite3.Row) -> dict[str, Any]:
    rows = json.loads(record["rows_json"])
    return {
        "hasData": True,
        "uploadId": record["id"],
        "filename": record["filename"],
        "sourceFormat": record["source_format"],
        "title": record["title"],
        "sourceTable": record["source_table"],
        "mapping": {
            "labelColumn": record["label_column"],
            "valueColumn": record["value_column"],
            **(json.loads(record["mapping_extra_json"]) if "mapping_extra_json" in record.keys() and record["mapping_extra_json"] else {}),
        },
        "rowCount": record["row_count"],
        "total": record["total_amount"],
        "rows": rows,
        "createdAt": record["created_at"],
    }


def ensure_mapping_extra_column() -> None:
    with db_connect() as connection:
        columns = {row["name"] for row in connection.execute("PRAGMA table_info(uploads)")}
        if "mapping_extra_json" not in columns:
            connection.execute("ALTER TABLE uploads ADD COLUMN mapping_extra_json TEXT NOT NULL DEFAULT '{}'")


ensure_mapping_extra_column()


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "reusable-donut-table-api"}


@app.get("/api/dashboard")
def get_dashboard() -> dict[str, Any]:
    with db_connect() as connection:
        record = connection.execute("SELECT * FROM uploads ORDER BY id DESC LIMIT 1").fetchone()
    if record is None:
        return {
            "hasData": False,
            "uploadId": None,
            "filename": None,
            "sourceFormat": None,
            "title": DEFAULT_TITLE,
            "sourceTable": None,
            "mapping": None,
            "rowCount": 0,
            "total": None,
            "rows": [],
            "createdAt": None,
        }
    return serialize_upload(record)


@app.post("/api/upload")
async def upload_data(file: UploadFile = File(...)) -> dict[str, Any]:
    filename = Path(file.filename or "uploaded-data").name
    suffix = Path(filename).suffix.casefold()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail="Unsupported file type. Upload JSON, CSV, TSV, XLSX, or XLSM.")
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File is too large. The maximum upload size is 15 MB.")
    try:
        normalized = parse_upload(filename, content)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    rows = normalized["rows"]
    title = normalized.get("title") or DEFAULT_TITLE
    mapping = normalized.get("mapping") or {}
    total = total_tree(rows)
    created_at = datetime.now(timezone.utc).isoformat()
    source_format = normalized.get("source_format", suffix.lstrip("."))
    row_count = count_tree(rows)
    with db_connect() as connection:
        cursor = connection.execute(
            """INSERT INTO uploads
               (filename, source_format, title, source_table, label_column, value_column,
                row_count, total_amount, rows_json, created_at, mapping_extra_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                filename, source_format, title, mapping.get("sourceTable"),
                mapping.get("labelColumn"), mapping.get("valueColumn"), row_count,
                total, json.dumps(rows, ensure_ascii=False), created_at,
                json.dumps({k: v for k, v in mapping.items() if k not in {"sourceTable", "labelColumn", "valueColumn"}}, ensure_ascii=False),
            ),
        )
        upload_id = cursor.lastrowid
        store_rows(connection, upload_id, rows)
        record = connection.execute("SELECT * FROM uploads WHERE id = ?", (upload_id,)).fetchone()
    return serialize_upload(record)


@app.delete("/api/dashboard")
def clear_dashboard() -> dict[str, Any]:
    with db_connect() as connection:
        connection.execute("DELETE FROM uploads")
    return {
        "hasData": False,
        "uploadId": None,
        "filename": None,
        "sourceFormat": None,
        "title": DEFAULT_TITLE,
        "sourceTable": None,
        "mapping": None,
        "rowCount": 0,
        "total": None,
        "rows": [],
        "createdAt": None,
    }
