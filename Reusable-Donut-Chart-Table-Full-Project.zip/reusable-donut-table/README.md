# Reusable Donut Chart + Table (standalone)

This is a separate, runnable React + TypeScript frontend and FastAPI backend. It does **not** import or modify the Sojourner/Personalised Dashboard code.

## What it does

- Starts with an empty chart and empty table when its database has no uploads.
- Accepts JSON, CSV, TSV, XLSX, and XLSM files.
- Parses ordinary row-oriented files automatically by detecting a name/category column and numeric measure column.
- Understands Sojourner gateway report JSON with `fields`, `fieldNature: "table"`, `tableField.headers`, and rows containing `columns[].value`.
- For Sojourner report JSON, prefers a project table and selects a likely budget/amount measure (e.g. `Global MYFP`, `Budget`, `Project MYFP`, donation amount, or another numeric measure).
- When a gateway JSON includes `Projects`, `Activity`, and `SubActivity` tables, links rows by their project/activity IDs when possible.
- Stores uploaded metadata and normalized hierarchical rows in a dedicated SQLite database at `backend/data/donut_table.sqlite3`.
- Shows which label and value fields the backend detected.
- Lets users expand nested table rows, select a chart segment/row, change currency formatting, and clear stored data.

## Requirements

- Python 3.10+
- Node.js 20.19+ (22.12+ recommended)
- npm

## Run locally

Open two terminals from the project root.

### Terminal 1 — backend

```bash
cd backend
python -m venv .venv
```

Activate the environment:

- macOS/Linux: `source .venv/bin/activate`
- Windows PowerShell: `.venv\Scripts\Activate.ps1`

Then run:

```bash
pip install -r requirements.txt
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Health endpoint: http://127.0.0.1:8000/api/health
Interactive API docs: http://127.0.0.1:8000/docs

### Terminal 2 — frontend

```bash
cd frontend
npm install
npm run dev
```

Open the local URL Vite prints, normally http://localhost:5173.

Vite forwards `/api` requests to the backend on `127.0.0.1:8000`.

## Accepted file structures

### 1. Sojourner gateway JSON

A report object with a `fields` array. Table fields use the same general shape as the uploaded dashboard reports:

- `fieldNature: "table"`
- `tableField.headers`
- `tableField.rows[].columns[].value`

For projects, a label column like `Project Name` / `Description` and a measure column like `Global MYFP` or `Budget` are automatically detected.

### 2. Ordinary JSON

A list of row objects, or an object with a `rows`, `records`, `data`, `items`, `projects`, or `donors` array. Include a name/category column and one numeric budget/amount/value column. Nested `children` arrays are supported.

### 3. CSV/TSV or Excel

The first row should have column headers. Recognized name columns include `Project Name`, `Project`, `Name`, `Category`, `Donor Name`, and `Description`. Recognized value columns include `Budget`, `Global MYFP`, `Donation Amount`, `Amount`, `Value`, and similar measures. The backend shows its detected mapping after upload.

## API

- `GET /api/health` — API status
- `GET /api/dashboard` — latest stored dataset, or an empty payload on a fresh database
- `POST /api/upload` — parse, map, normalize, validate, and persist an uploaded file
- `DELETE /api/dashboard` — clear stored datasets from this module

Uploads are limited to 15 MB. Parsing and field mapping occur on the backend; normalized records are stored in the module's SQLite database. No uploaded data is sent to the main dashboard or its API.

## Important deployment note

This standalone version uses a local SQLite database and does not include user authentication. It is suitable for local use and as a separately deployable module. Before exposing it to multiple users publicly, add authentication/authorization and partition stored records by user or tenant; otherwise users sharing the same running instance share the active dataset.
