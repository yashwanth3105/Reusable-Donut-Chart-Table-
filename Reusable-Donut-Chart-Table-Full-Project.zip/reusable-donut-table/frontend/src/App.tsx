import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { AlertCircle, CheckCircle2, ChevronDown, ChevronRight, Database, FileSpreadsheet, FileText, LoaderCircle, Trash2, UploadCloud } from "lucide-react";

type DataRow = {
  id: string;
  name: string;
  amount: number | null;
  children?: DataRow[];
};
type Mapping = {
  labelColumn?: string | null;
  valueColumn?: string | null;
  sourceTable?: string | null;
  nestedValueColumns?: string | null;
  sourceFormat?: string | null;
};
type DashboardPayload = {
  hasData: boolean;
  uploadId: number | null;
  filename: string | null;
  sourceFormat: string | null;
  title: string;
  sourceTable: string | null;
  mapping: Mapping | null;
  rowCount: number;
  total: number | null;
  rows: DataRow[];
  createdAt: string | null;
};

const EMPTY: DashboardPayload = {
  hasData: false, uploadId: null, filename: null, sourceFormat: null,
  title: "Total Budget by Project", sourceTable: null, mapping: null,
  rowCount: 0, total: null, rows: [], createdAt: null,
};
const SEGMENT_COLORS = ["#356AE6", "#16A085", "#E9A23B", "#9367D8", "#E16A83", "#2999B5"];

function formatAmount(value: number | null, currency = true) {
  if (value === null || !Number.isFinite(value)) return "—";
  return `${currency ? "$" : ""}${value.toLocaleString("en-US", {
    minimumFractionDigits: currency ? 2 : 0,
    maximumFractionDigits: 2,
  })}`;
}
function positiveTotal(rows: DataRow[]) {
  return rows.reduce((sum, row) => sum + (typeof row.amount === "number" && row.amount > 0 ? row.amount : 0), 0);
}
function allIds(rows: DataRow[]): string[] {
  return rows.flatMap((row) => [row.id, ...allIds(row.children ?? [])]);
}
function countVisible(rows: DataRow[], expanded: Set<string>): number {
  return rows.reduce((count, row) => count + 1 + (expanded.has(row.id) ? countVisible(row.children ?? [], expanded) : 0), 0);
}
function errorMessage(value: unknown): string {
  if (value && typeof value === "object" && "detail" in value) return String((value as {detail: unknown}).detail);
  return "Something went wrong. Please try again.";
}

export default function App() {
  const [data, setData] = useState<DashboardPayload>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");
  const [currency, setCurrency] = useState(true);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/dashboard");
      if (!response.ok) throw new Error(`Dashboard API returned ${response.status}`);
      const result = await response.json() as DashboardPayload;
      setData(result);
      setError("");
    } catch {
      setError("Cannot reach the backend. Start the API server, then refresh this page.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadDashboard(); }, [loadDashboard]);

  const topLevelTotal = data.total;
  const chartTotal = useMemo(() => positiveTotal(data.rows), [data.rows]);
  const visibleRows = useMemo(() => {
    const output: { row: DataRow; depth: number }[] = [];
    const visit = (rows: DataRow[], depth: number) => rows.forEach((row) => {
      output.push({ row, depth });
      if (expanded.has(row.id)) visit(row.children ?? [], depth + 1);
    });
    visit(data.rows, 0);
    return output;
  }, [data.rows, expanded]);

  const uploadFile = async (file: File) => {
    setUploading(true);
    setError("");
    setStatus("");
    const form = new FormData();
    form.append("file", file);
    try {
      const response = await fetch("/api/upload", { method: "POST", body: form });
      const result = await response.json();
      if (!response.ok) throw new Error(errorMessage(result));
      setData(result as DashboardPayload);
      setExpanded(new Set());
      setSelectedId(null);
      setStatus(`Uploaded and analyzed ${file.name}. The results have been stored in the backend database.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "The upload failed.");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const onFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) void uploadFile(file);
  };

  const clearData = async () => {
    if (!window.confirm("Clear the stored dataset from this standalone module?")) return;
    setClearing(true);
    setError("");
    setStatus("");
    try {
      const response = await fetch("/api/dashboard", { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(errorMessage(result));
      setData(result as DashboardPayload);
      setExpanded(new Set());
      setSelectedId(null);
      setStatus("Stored data was cleared. The chart and table are empty again.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not clear stored data.");
    } finally {
      setClearing(false);
    }
  };

  const toggleRow = (id: string) => setExpanded((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });
  const expandAll = () => setExpanded((current) => current.size ? new Set() : new Set(allIds(data.rows)));

  const circumference = 2 * Math.PI * 72;
  let strokeOffset = 0;

  return (
    <main className="page-shell">
      <div className="page-content">
        <header className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-dot" /> Standalone analytics module</div>
            <h1>Total Budget by Project</h1>
            <p>Upload a report file. The backend identifies the relevant fields, stores the normalized data, and renders the results below.</p>
          </div>
          <div className="hero-mark"><span className="hero-mark-ring" /><span className="hero-mark-hole" /></div>
        </header>

        <section className="upload-card">
          <div className="upload-main">
            <div className="upload-icon"><UploadCloud size={24} strokeWidth={1.8} /></div>
            <div className="upload-copy">
              <h2>Upload your data</h2>
              <p>JSON, CSV, TSV, or Excel (.xlsx / .xlsm). Data is parsed and mapped by the separate backend.</p>
            </div>
            <input ref={inputRef} className="file-input-hidden" type="file" accept=".json,.csv,.tsv,.xlsx,.xlsm,application/json,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={onFileChange} />
            <button className="primary-button" type="button" disabled={uploading || loading} onClick={() => inputRef.current?.click()}>
              {uploading ? <LoaderCircle className="spin" size={17} /> : <UploadCloud size={17} />}
              {uploading ? "Analyzing file…" : "Choose data file"}
            </button>
          </div>
          <div className="upload-footer">
            <div className="file-types">
              <span><FileText size={14} /> JSON</span><span><FileSpreadsheet size={14} /> CSV / TSV</span><span><FileSpreadsheet size={14} /> XLSX</span>
            </div>
            <p><Database size={14} /> Stored in this module’s own SQLite database</p>
          </div>
          {(error || status) && <div className={error ? "notice notice-error" : "notice notice-success"} role={error ? "alert" : "status"}>
            {error ? <AlertCircle size={17} /> : <CheckCircle2 size={17} />}
            <span>{error || status}</span>
          </div>}
        </section>

        <section className="dashboard-card">
          <div className="card-heading">
            <div>
              <p className="section-kicker">DATA VISUALIZATION</p>
              <h2>{data.title || "Total Budget by Project"}</h2>
              <p className="card-subtitle">
                {loading ? "Connecting to backend…" : data.hasData ? `${data.rows.length} top-level rows · ${data.rowCount} total rows` : "No dataset loaded yet"}
              </p>
            </div>
            <div className="heading-actions">
              <label className="currency-toggle"><input type="checkbox" checked={currency} onChange={(event) => setCurrency(event.target.checked)} /> Show currency</label>
              {data.hasData && <button className="secondary-button" type="button" onClick={expandAll}>{expanded.size ? "Collapse all" : "Expand all"}</button>}
              {data.hasData && <button className="icon-button" type="button" title="Clear active dataset" aria-label="Clear stored dataset" disabled={clearing} onClick={() => void clearData()}><Trash2 size={16} /></button>}
            </div>
          </div>

          {data.mapping && <div className="mapping-bar">
            <CheckCircle2 size={15} />
            <span>Auto-mapped fields:</span>
            <strong>{data.mapping.labelColumn || "Name"}</strong>
            <span className="mapping-arrow">→</span>
            <strong>{data.mapping.valueColumn || "Amount"}</strong>
            {data.mapping.sourceTable && <span className="mapping-source">from {data.mapping.sourceTable}</span>}
          </div>}

          <div className="visual-grid">
            <section className="chart-panel" aria-label="Donut chart">
              <div className="panel-title"><h3>Donut chart</h3><span>Project totals</span></div>
              <div className="donut-wrap">
                <svg className="donut-svg" viewBox="0 0 200 200" role="img" aria-label="Donut chart of uploaded project totals">
                  <circle cx="100" cy="100" r="72" fill="none" stroke="#edf1f7" strokeWidth="25" />
                  {chartTotal > 0 && data.rows.map((row, index) => {
                    const amount = typeof row.amount === "number" ? Math.max(row.amount, 0) : 0;
                    const dash = amount / chartTotal * circumference;
                    const segment = <circle key={row.id} cx="100" cy="100" r="72" fill="none" stroke={SEGMENT_COLORS[index % SEGMENT_COLORS.length]} strokeWidth="25" strokeDasharray={`${dash} ${circumference - dash}`} strokeDashoffset={-strokeOffset} className={selectedId === row.id ? "donut-segment selected" : "donut-segment"} onClick={() => setSelectedId(row.id)} tabIndex={0} aria-label={`${row.name}: ${formatAmount(row.amount, currency)}`} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") setSelectedId(row.id); }} />;
                    strokeOffset += dash;
                    return segment;
                  })}
                </svg>
                <div className="donut-center">
                  <strong>{formatAmount(topLevelTotal, currency)}</strong>
                  <span>Total budget</span>
                </div>
              </div>
              <div className="legend-list">
                {data.rows.length ? data.rows.map((row, index) => (
                  <button key={row.id} type="button" className={selectedId === row.id ? "legend-item active" : "legend-item"} onClick={() => setSelectedId(row.id)}>
                    <span className="legend-dot" style={{ background: SEGMENT_COLORS[index % SEGMENT_COLORS.length] }} />
                    <span className="legend-name" title={row.name}>{row.name}</span>
                    <strong>{formatAmount(row.amount, currency)}</strong>
                    <span className="legend-share">{chartTotal > 0 && typeof row.amount === "number" && row.amount >= 0 ? `${(row.amount / chartTotal * 100).toFixed(1)}%` : "—"}</span>
                  </button>
                )) : <div className="empty-legend"><span className="empty-dot" /> Project labels and amounts appear here after upload.</div>}
              </div>
            </section>

            <section className="table-panel" aria-label="Interactive budget table">
              <div className="panel-title"><h3>Data table</h3><span>{countVisible(data.rows, expanded)} visible rows</span></div>
              <div className="table-scroll">
                <table>
                  <thead><tr><th>Project / Activity</th><th className="numeric">{currency ? "Amount ($)" : "Amount"}</th><th className="numeric">Share</th></tr></thead>
                  <tbody>
                    {visibleRows.length ? visibleRows.map(({ row, depth }) => (
                      <tr key={row.id} className={selectedId === row.id ? "selected-row" : ""}>
                        <td style={{ paddingLeft: `${14 + depth * 23}px` }}>
                          <div className="tree-name">
                            {row.children?.length ? <button className="tree-toggle" type="button" aria-label={expanded.has(row.id) ? `Collapse ${row.name}` : `Expand ${row.name}`} onClick={() => toggleRow(row.id)}>{expanded.has(row.id) ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</button> : <span className="tree-spacer" />}
                            <button type="button" className="row-name" onClick={() => setSelectedId(row.id)}>{row.name}</button>
                          </div>
                        </td>
                        <td className="numeric amount-cell">{formatAmount(row.amount, currency)}</td>
                        <td className="numeric share-cell">{depth === 0 && chartTotal > 0 && typeof row.amount === "number" && row.amount >= 0 ? `${(row.amount / chartTotal * 100).toFixed(1)}%` : "—"}</td>
                      </tr>
                    )) : (
                      <tr className="empty-table-row"><td><span className="empty-row-icon" /> No project data yet</td><td className="numeric">—</td><td className="numeric">—</td></tr>
                    )}
                  </tbody>
                  <tfoot><tr><td>Total</td><td className="numeric">{formatAmount(topLevelTotal, currency)}</td><td className="numeric">{chartTotal > 0 ? "100%" : "—"}</td></tr></tfoot>
                </table>
              </div>
              <p className="table-footnote">Expand a project row to view nested activities. The donut uses top-level rows only, so details are not counted twice.</p>
            </section>
          </div>

          <div className="card-bottom">
            <span>{selectedId ? `Selected: ${findRowName(data.rows, selectedId) ?? selectedId}` : "Select a chart segment or table row to inspect it."}</span>
            <span>{data.filename ? `Source file: ${data.filename}` : "Waiting for uploaded data"}</span>
          </div>
        </section>
        <footer className="page-footer">Independent reusable module · Backend analysis and SQLite persistence · Not connected to the main dashboard</footer>
      </div>
    </main>
  );
}

function findRowName(rows: DataRow[], id: string): string | null {
  for (const row of rows) {
    if (row.id === id) return row.name;
    if (row.children?.length) {
      const found = findRowName(row.children, id);
      if (found) return found;
    }
  }
  return null;
}
